package com.example.randomizerapp

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class CoinFlipActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_coin_flip)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setTitle("Flip Coin")

        val coinImage = findViewById<ImageView>(R.id.coin_face_image)
        coinImage.setImageResource(R.drawable.face)

        findViewById<Button>(R.id.flip_coin_button).setOnClickListener{
            findViewById<ImageView>(R.id.coin_face_image)
                .setImageResource(listOf(R.drawable.face, R.drawable.cross).random())

            Snackbar.make(coinImage, "Coin Flipped", Snackbar.LENGTH_SHORT).show()



        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean{

        if(item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }
}